package project.taoussiAbouelaoud.gestionTicket;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import project.taoussiAbouelaoud.gestionTicket.security.services.SecurityService;



@SpringBootApplication
public class ProjectGestionTicketApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectGestionTicketApplication.class, args);
	}
	 @Bean
	    PasswordEncoder passwordEncoder(){
	        return new BCryptPasswordEncoder();
	    }

	    //@Bean
	    CommandLineRunner saveUsers(SecurityService securityService){
	        return args -> {
	            securityService.saveNewUser("abdelbast", "123", "123");
	            securityService.saveNewUser("dev", "123", "123");
	            securityService.saveNewUser("client", "123", "123");
	           
	            securityService.saveNewRole("ADMIN", "Admin");
	            securityService.saveNewRole("DEVELOPPEUR", "Developpeur");
	            securityService.saveNewRole("CLIENT", "client");
	            
	            securityService.addRoleToUser("abdelbast", "ADMIN");
	            securityService.addRoleToUser("dev", "DEVELOPPEUR");
	            securityService.addRoleToUser("client", "CLIENT");
	   
	            
	            
	        	
	        	securityService.saveNewUser("dev1", "123", "123");
	        	securityService.saveNewUser("dev2", "123", "123");
	        	  securityService.addRoleToUser("dev1", "DEVELOPPEUR");
	        	  securityService.addRoleToUser("dev2", "DEVELOPPEUR");
	        };
	    }
}
