package project.taoussiAbouelaoud.gestionTicket.services;

import java.util.List;

import project.taoussiAbouelaoud.gestionTicket.models.Developpeur;
import project.taoussiAbouelaoud.gestionTicket.models.Ticket;

public interface DeveloppeurService {

	 void updateStatus (String status, long id_tic);
	List<Ticket> findAll_byIdDev(Long id);
	 Long findIdByUsername(String nom);
	  List<Developpeur> findAll();
}
