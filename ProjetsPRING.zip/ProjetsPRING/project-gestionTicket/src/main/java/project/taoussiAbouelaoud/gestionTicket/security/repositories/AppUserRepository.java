package project.taoussiAbouelaoud.gestionTicket.security.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import project.taoussiAbouelaoud.gestionTicket.security.entities.AppUser;

public interface AppUserRepository extends JpaRepository<AppUser, String> {
    AppUser findByUsername(String username);
}
